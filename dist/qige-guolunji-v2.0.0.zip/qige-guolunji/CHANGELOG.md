# CHANGELOG

## [2.0.0-public] — 2026-09-16（公开发布版）

为适配公开发布，在 2.0.0 基础上做了**去原话化**处理：

- 16 个 skill 的 `## R — 原文` 段 → `## R — 出处 (Source)`，只保留出处坐标（文件 + 时间戳）
- `docs/DIGEST.md` 等文档中的引文块 → 出处行；内嵌原话 → 提炼者重述
- `ATTRIBUTION.md`（含 60 条原话）→ `SOURCES.md`（纯出处索引，无原话）
- `LICENSE` / `DISCLAIMER.md` / `README.md` / `LICENSING.md` 同步更新
- 校验：发布内容与原始语料的 **20 字窗口逐字重合 = 0**

## [2.0.0] — 2026-09-16

### 新增（8 个 skill）

从 89 篇直播文字稿（148.6 万字符，2023-12 ~ 2026-09）全量重新蒸馏，
经 5 路并行提取 → 148 条候选 → 三重验证，新增：

**约束层**
- `timing-window-cadence` —— 时间窗与节奏控制（日历节点 / 节奏归属 / 谈判即消耗）

**读牌层**
- `adversary-intent-read` —— 对手意图与底牌读取（异常动作 / 手段缺席 / 两套说辞 / 示弱欺骗）
- `causal-chain-consistency` —— 来龙去脉一致性检验（事件链闭合 + 三条停止解释的元规则）
- `forecast-self-audit` —— 预测自审与证伪（强制补"除非…" / 拒绝单变量 / 拒绝远期具体化）

**主体层**
- `patronage-value-grading` —— 统战价值与代理人分级（价值打分 / 盘棋 vs 家族集团 / 追买单人）
- `coalition-fracture-index` —— 同盟裂痕与反围剿识别（信用锚点 / 第一道防线的口子）

**评估与收场层**
- `strategy-tactics-audit` —— 战略/战术分层审计（两把尺 + 开战权/主动权/结束权）
- `endgame-scripting` —— 剧本化推演（非对称胜负 → 最优收敛态 → 终局分工 → 留盼头）

### 新增（入口）

- `qige-analysis` —— 总纲与路由器：九步分析链 + 16 个 skill 的分派表

### 变更（v1 的 7 个 skill）

- 全部补 `family: qige-guolunji` 与 `family_version: 2.0.0` 元数据
- 全部补**对称路由指引**（"问 X 请转 Y"），消除兄弟 skill 互相抢调用
- 内容主体**未改动**，保留 v1 的 RIA++ 结构

### 新增（文档）

- `docs/DIGEST.md` —— 方法论说明书（九步链 + 三条不变式 + 已知硬伤）
- `docs/GLOSSARY.md` —— 黑话词典（65+ 条，含代称、结构概念、自造词）
- `docs/INDEX.md` —— 整合设计与去重说明
- `docs/BOOK_OVERVIEW.md` —— 语料骨架（四幕剧）与批判
- `docs/VERIFICATION.md` —— 三重验证与筛选依据（含淘汰理由）
- `docs/TEST-RESULTS.md` —— 路由盲测记录
- `docs/VETTING-REPORT.md` —— skill-vetter 安全审查报告
- `SOURCES.md` —— 语料出处索引（公开发布版：无原话引用）
- `index.json` —— 机器可读技能清单
- `.codex-plugin/plugin.json` —— Codex 插件清单

### 质量数据

| 项 | 结果 |
|---|---|
| 提取候选 | 148 条 |
| 引文回验 | 160 / 160 逐字通过 |
| 路由盲测（96 用例） | 首轮 88/96 (91.7%) → 修补后 92/96 (95.8%) |
| 诱饵误触发 | 0 / 32 |
| 安全审查红 flag | 0 |

### 已知问题

- 8 个新 skill 的提取以"预筛证据 + 定向检索"为主，未逐字通读全部语料
- 路由测试第二轮属"修补后复测同题"，泛化能力待新题验证
- v1 的 7 个 skill 保留了 2026-08 蒸馏时的 `test-results.md`

---

## [1.0.0] — 2026-08-12

首版，7 个 skill：

- `map-first-geostrategy` —— 地图优先的地理位势分析
- `great-power-master-switch` —— 中美总开关/大格局归因
- `proxy-war-cost-trace` —— 代理人战争成本追踪
- `attrition-long-game` —— 消耗战与马拉松时间观
- `hegemony-collapse-chain` —— 霸权塌方链
- `industrial-base-power-check` —— 工业地基核验
- `structural-necessity-forecast` —— 结构必然性预测
