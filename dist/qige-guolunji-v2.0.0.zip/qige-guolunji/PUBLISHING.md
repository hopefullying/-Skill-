# PUBLISHING · 发布指南

发布前请逐项确认。**带 ⚠️ 的是必须你亲自决定的，我不能替你决定。**

---

## ⚠️ 一、发布前的三个必决项

### 1. 授权（licensing）
当前默认 `CC BY-NC-SA 4.0`。若不认同，改 `LICENSE` + `README.md` 徽章。
决策说明见 `LICENSING.md`。

### 2. 直接引用 —— ✅ 已按方案 C 处理完毕
**当前状态：全包零原话引用。** 16 个 skill 的 `## R` 段只有出处坐标，
文档中的引文块已改为出处行，`ATTRIBUTION.md` 已替换为无原话的 `SOURCES.md`。

校验记录：发布内容与原始语料做 20 字窗口全量比对，**逐字重合 = 0**。

恢复引用版的模板保留在工作区 `work/backup_release_with_quotes/`（**不在发布包内**）。

### 3. 署名与仓库地址
需替换的占位符：

| 文件 | 字段 | 当前值 |
|---|---|---|
| `.codex-plugin/plugin.json` | `author.name` / `interface.developerName` | `qige-guolunji contributors` |
| `.codex-plugin/plugin.json` | `homepage` / `repository` | `https://github.com/REPLACE-ME/qige-guolunji` |
| `README.md` | 两处 `<your-repo-url>` | 占位 |

---

## 二、发布到 GitHub

```bash
cd qige-guolunji          # 解压 qige-guolunji-v2.0.0.zip 后得到
git init
git add .
git commit -m "feat: qige-guolunji v2.0.0 — 16 skills distilled from 89 live transcripts"
git branch -M main
git remote add origin https://github.com/<you>/qige-guolunji.git
git push -u origin main
```

### 建议的仓库设置
- **Description**：`七哥论国际 · 分析方法论 Skill 集 — 16 个可被 AI agent 调用的原子化 skill`
- **Topics**：`geopolitics` `methodology` `ai-skills` `chinese` `analysis-framework`
- **License**：选 `Creative Commons Attribution Non Commercial Share Alike 4.0`
- **勾选 Issues**（用于接收权利人的移除请求）

### 打 tag 与 Release

```bash
git tag -a v2.0.0 -m "qige-guolunji v2.0.0"
git push origin v2.0.0
```

在 GitHub Release 里上传 `dist/` 下三个文件作为 Assets。

---

## 三、作为 Codex 插件发布

`.codex-plugin/plugin.json` 已通过 `validate_plugin.py` 校验。
若要进个人 marketplace：

```bash
python3 ~/.codex/skills/.system/plugin-creator/scripts/create_basic_plugin.py qige-guolunji \
  --with-marketplace --with-skills
```

然后把本包的 `skills/` 内容覆盖进生成的插件目录，并重新跑
`update_plugin_cachebuster.py`。

---

## 四、只发 skills（最快路径）

如果不想发整个仓库，只发 `qige-guolunji-skills-only-v2.0.0.zip`：

```
用户解压 → 把 16 个目录拖进 ~/.codex/skills/ → 完成
```

适合发在论坛/群文件/网盘。

---

## 五、发布后建议

1. **加一个移除通道**：在 README 写明"权利人可联系移除"，并留一个联系方式
2. **跟进反馈**：路由误触发是最可能的反馈类型，收进 `test-prompts.json` 再跑盲测
3. **版本纪律**：新增/修改 skill 时递增 `family_version`，并在 `CHANGELOG.md` 记账
4. **完整性校验**：把 `dist/` 与 `index.json` 一起发；用户可用 `index.json` 核对技能清单

---

## 六、不要发布的东西

| 内容 | 原因 |
|---|---|
| 原始转写全文（148.6 万字） | 原讲者作品的完整复制，非"短引用 + 提炼" |
| 飞书文件夹链接 / token | 私有资源标识 |
| 蒸馏工作区（`work/`） | 含本机路径、备份、中间产物 |
| 评论/弹幕原始数据 | 未做授权评估 |


---

## 七、内部版 vs 公开发布版（重要）

本机 `~/.codex/skills/` 里安装的是**内部版**，与本发布包**有意不同**：

| | 内部版（已安装） | 公开发布版（本包） |
|---|---|---|
| 原话引用 | **保留**（便于溯源与本地使用） | **全部移除** |
| `## R` 段 | R — 原文（含引文） | R — 出处（仅坐标） |
| 引用索引 | — | `SOURCES.md` |
| 逐字重合 | 有 | **0** |
| 适用场景 | 自用、内部研究 | 公开分发 |

两者方法论内容（I / A1 / A2 / E / B 段）**完全一致**。
如要把公开发布版同步回本机，覆盖 `~/.codex/skills/` 下同名目录即可
（代价：本地将失去原文对照）。

内部版模板保留在 `work/backup_release_with_quotes/`。
